import 'package:flutter/material.dart';
import 'package:router/router.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final router = Router(
    routes: {
      '/': (_) => MaterialPage(child: TabBarAppWidget()),
      '/info': (_) => MaterialPage(child: InfoScreen()),
      '/settings': (_) => MaterialPage(child: SettingsScreen()),
    },
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'TabBar App',
      routerDelegate: router.routerDelegate,
      routeInformationParser: router.routeInformationParser,
    );
  }
}

class TabBarAppWidget extends StatefulWidget {
  @override
  _TabBarAppWidgetState createState() => _TabBarAppWidgetState();
}

class _TabBarAppWidgetState extends State<TabBarAppWidget> {
  int _selectedIndex = 0;

  final List<Widget> _screens = [
    InfoScreen(),
    SettingsScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TabBar App'),
      ),
      body: IndexedStack(
        index: _selectedIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'Info',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
        ],
      ),
    );
  }
}

class InfoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Info Screen',
        style: TextStyle(fontSize: 24.0),
      ),
    );
  }
}

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Settings Screen',
        style: TextStyle(fontSize: 24.0),
      ),
    );
  }
}
